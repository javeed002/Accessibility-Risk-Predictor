import os, joblib, pandas as pd
from .train import FEATURES, MODEL, train
_m = None
NAMES = ["Low", "Medium", "High"]
WEIGHT = [15, 55, 90]

def predict_risk(counts):
    global _m
    if _m is None:
        _m = joblib.load(MODEL) if os.path.exists(MODEL) else train()
    X = pd.DataFrame([{f: counts.get(f, 0) for f in FEATURES}])
    proba = _m.predict_proba(X)[0]
    classes = list(_m.classes_)
    score = sum(p * WEIGHT[c] for p, c in zip(proba, classes))
    return round(float(score), 1), NAMES[classes[int(proba.argmax())]]
