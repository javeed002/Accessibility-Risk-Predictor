"""Trains the accessibility risk model (Pandas/NumPy data + Scikit-learn).
Run: python backend/ml/train.py
Replace make_data() with real scan data from the `scans` table as you collect it."""
import os, numpy as np, pandas as pd, joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
FEATURES = ["critical", "serious", "moderate", "minor", "incomplete", "passes", "dom_nodes"]
MODEL = os.path.join(os.path.dirname(__file__), "model.joblib")

def make_data(n=4000, seed=42):
    r = np.random.default_rng(seed)
    df = pd.DataFrame({"critical": r.poisson(1.0, n), "serious": r.poisson(2, n), "moderate": r.poisson(3, n),
                       "minor": r.poisson(2, n), "incomplete": r.poisson(3, n),
                       "passes": r.integers(10, 60, n), "dom_nodes": r.integers(50, 5000, n)})
    raw = (df.critical * 10 + df.serious * 6 + df.moderate * 3 + df.minor + df.incomplete * .5
           - df.passes * .1 + df.dom_nodes * .002 + r.normal(0, 2, n))
    df["label"] = pd.cut(raw, [-1e9, 10, 28, 1e9], labels=[0, 1, 2]).astype(int)  # 0 low,1 medium,2 high
    return df

def train():
    df = make_data()
    Xtr, Xte, ytr, yte = train_test_split(df[FEATURES], df.label, test_size=.2, random_state=1)
    m = RandomForestClassifier(n_estimators=200, random_state=1).fit(Xtr, ytr)
    print(classification_report(yte, m.predict(Xte), target_names=["Low", "Medium", "High"]))
    joblib.dump(m, MODEL)
    return m

if __name__ == "__main__":
    train()
