"""FastAPI app: connects frontend, scanner (axe-core + Playwright) and ML model.
Run from project root:  uvicorn backend.main:app --reload"""
import os, sqlite3
from fastapi import FastAPI, HTTPException, Header
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from . import db, scanner
from .ml.predictor import predict_risk

db.init()
app = FastAPI(title="AI-Based Website UI Accessibility Risk Predictor")

class Cred(BaseModel):
    username: str
    password: str

class ScanReq(BaseModel):
    url: str

def current(authorization: str | None):
    u = db.user_from_token((authorization or "").replace("Bearer ", ""))
    if not u:
        raise HTTPException(401, "Not authenticated")
    return u

@app.post("/api/register")
def register(c: Cred):
    if len(c.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    try:
        db.create_user(c.username.strip(), c.password)
    except sqlite3.IntegrityError:
        raise HTTPException(400, "Username already exists")
    return {"token": db.login(c.username.strip(), c.password), "username": c.username}

@app.post("/api/login")
def login(c: Cred):
    t = db.login(c.username.strip(), c.password)
    if not t:
        raise HTTPException(401, "Invalid username or password")
    return {"token": t, "username": c.username}

@app.post("/api/scan")
def scan(r: ScanReq, authorization: str | None = Header(None)):
    u = current(authorization)
    url = r.url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        counts, violations = scanner.scan(url)
    except Exception as e:
        raise HTTPException(400, f"Could not scan page: {str(e)[:200]}")
    score, risk = predict_risk(counts)
    sid = db.save_scan(u["id"], url, score, risk, counts, violations)
    return {"id": sid, "url": url, "score": score, "risk": risk, "counts": counts, "violations": violations}

@app.get("/api/scans")
def scans(authorization: str | None = Header(None)):
    return db.list_scans(current(authorization)["id"])

app.mount("/", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "..", "frontend"), html=True))
