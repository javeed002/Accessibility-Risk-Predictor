"""SQLite storage for users, sessions and scan results.
To use MySQL instead, swap sqlite3 for mysql-connector / SQLAlchemy and keep the same tables."""
import sqlite3, os, hashlib, secrets, json
DB = os.path.join(os.path.dirname(__file__), "app.db")

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100_000).hex()

def check_pw(pw, stored):
    return hash_pw(pw, stored.split("$")[0]) == stored

def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER);
        CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY, user_id INTEGER, url TEXT,
            score REAL, risk TEXT, counts TEXT, violations TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        if not c.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
            c.execute("INSERT INTO users(username,password) VALUES('admin',?)", (hash_pw("Admin@123"),))

def create_user(u, p):
    with conn() as c:
        c.execute("INSERT INTO users(username,password) VALUES(?,?)", (u, hash_pw(p)))

def login(u, p):
    with conn() as c:
        r = c.execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
        if not r or not check_pw(p, r["password"]):
            return None
        t = secrets.token_urlsafe(24)
        c.execute("INSERT INTO sessions VALUES(?,?)", (t, r["id"]))
        return t

def user_from_token(t):
    with conn() as c:
        r = c.execute("SELECT u.id,u.username FROM sessions s JOIN users u ON u.id=s.user_id WHERE token=?", (t,)).fetchone()
        return dict(r) if r else None

def save_scan(uid, url, score, risk, counts, violations):
    with conn() as c:
        cur = c.execute("INSERT INTO scans(user_id,url,score,risk,counts,violations) VALUES(?,?,?,?,?,?)",
                        (uid, url, score, risk, json.dumps(counts), json.dumps(violations)))
        return cur.lastrowid

def list_scans(uid):
    with conn() as c:
        rows = c.execute("SELECT * FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 50", (uid,)).fetchall()
    out = []
    for r in rows:
        d = dict(r); d["counts"] = json.loads(d["counts"]); d["violations"] = json.loads(d["violations"]); out.append(d)
    return out
