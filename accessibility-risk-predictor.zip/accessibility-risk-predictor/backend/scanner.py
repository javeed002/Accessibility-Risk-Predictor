"""Opens a page with Playwright and runs axe-core inside it."""
import os
from playwright.sync_api import sync_playwright
AXE_LOCAL = os.path.join(os.path.dirname(__file__), "axe.min.js")  # optional offline copy
AXE_CDN = "https://cdnjs.cloudflare.com/ajax/libs/axe-core/4.10.2/axe.min.js"

def scan(url):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(url, wait_until="load", timeout=45000)
        if os.path.exists(AXE_LOCAL):
            page.add_script_tag(path=AXE_LOCAL)
        else:
            page.add_script_tag(url=AXE_CDN)
        res = page.evaluate("axe.run()")
        dom_nodes = page.evaluate("document.getElementsByTagName('*').length")
        browser.close()
    counts = {k: 0 for k in ("critical", "serious", "moderate", "minor")}
    violations = []
    for v in res["violations"]:
        counts[v.get("impact") or "minor"] += 1
        violations.append({"id": v["id"], "impact": v.get("impact"), "help": v["help"],
                           "helpUrl": v["helpUrl"], "nodes": len(v["nodes"])})
    counts.update(incomplete=len(res["incomplete"]), passes=len(res["passes"]), dom_nodes=dom_nodes)
    return counts, violations
